Dear students,

here you will find the data for the XPS experiment sorted out by tasks.

Task 1. 
Silver (Ag) sample was introduced in analysis chamber and measured by XPS. We have monitored the peak that corresponds to Ag3d core electrons for different pass energies. You should confirm that this is Ag3d by finding the binding energy of the peak and compare it with table of elements. Here are list of important parameters you will find in you raw data files:

# Region:            Ag3d                           <--- region that was monitored
# Acquisition Date:  04/27/20 12:19:19 UTC
# Analysis Method:   XPS
# Analyzer Lens:     MediumArea:1.5kV
# Analyzer Slits:    0.2/7                          <--- dimensions of input and output slit, respectively. Units are in mm
# Scan Mode:         FixedAnalyzerTransmission
# Curves/Scan:       1                              
# Values/Curve:      457                            <--- Number of taken data points
# Dwell Time:        0.2
# Excitation Energy: 1253.64                        <--- Excitation energy of our X-ray gun in eV
# Kinetic Energy:    859.238                        <--- Lowest value of kinetic energy in eV
# Pass Energy:       5                              <--- pass energy in eV
# Bias Voltage:      90
# Detector Voltage:  3300
# Eff. Workfunction: 4.2627                         <--- Work function of the detector in eV
# Source:            X-Ray Dummy
# Comment:           
#
# Cycle: 0
# Number of Scans: 1                                <--- How many times spectra is taken. If larger than 1 then the data is averaged over number of scans.
#
# Cycle: 0, Curve: 0
# Acquisition Date: 04/27/20 12:24:40 UTC
#
# ColumnLabels: energy counts/s                     <--- first column is kinetic energy in eV and second one signal itself given in counts per second
#
859.23845  12283.362                                <--- first row of the data itself

For this task we made 14 scans of the same peak for 14 different pass energies. You should find correlation between FWHM of the peak with respect to the pass energy.

Task 2.
In task 2 you get an unknown compound. First overview spectra is taken and then three peaks are recorded separately. You have to find binding energy of the peaks and compare them to the table of elements so you can identify them (element and orbital). Exclude any surface contamination. Finally, you should also find atomic ratio between elements that compose the material (using atomic sensitivity) and give the chemical formula of the compound.

Task 3.
In task 3 you get an unknown compound. First overview spectra is taken and then doublet peaks are recorded. You have to determine the binding energy of the doublet peaks and to identify the element and orbital. Finally, you need to determine the doublet ratio and compare it to the theoretical value.

Task 4.
In task 4 you get two unknown compounds with one common element. We provide you with overview spectra for both compounds and 2 peaks for each compound. You have to determine the binding energy of the peaks and to identify elements and orbitals. For common element present in both compounds you need to determine the chemical shift. You can also try to identify the compounds but that is only if you have spare time (basically repetition of task 2 by using atomic sensitivity).

Task 5.
In task 5 ITO (indium-tin-oxide) sample is measured for different sputtering time: sp0h means no sputtring, while sp4h means that spectra is taken after 4 hours of sputtering with Argon gun, sp7h is 7 hours of sputtering and sp11h 11 hours of sputtering. Each time we have taken overview spectra and 3 peaks are recorded in details (region 1, region 2, region 3). You need to find binding energy of the peaks and identify the elements and orbitals they belong to. After that you need to determine the intensity of the peaks as a function of sputtering time (you should get 3 curves). 


If you have any questions, feel free to ask them.
